from flask import Flask, request, render_template
import pickle
import numpy as np
# import sklearn

app = Flask(__name__)


with open("model","rb") as f:
    model=pickle.load(f)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/result.html', methods=['POST'])
def result():
    name = request.form.get("Name")
    age = request.form.get("age")
    sex = request.form.get("sex")
    chest_pain_type = request.form.get("chest_pain_type")
    bp = request.form.get("bp")
    cholesterol = request.form.get("cholesterol")
    fbs_over_120 = request.form.get("fbs_over_120")
    ekg_results = request.form.get("ekg_results")
    max_hr = request.form.get("max_hr")
    exercise_angina = request.form.get("exercise_angina")
    st_depression = request.form.get("st_depression")
    slope_of_st = request.form.get("slope_of_st")
    number_of_vessels = request.form.get("number_of_vessels")
    thallium = request.form.get("thallium")
    
    input_array = np.array([[age, sex, chest_pain_type, bp, cholesterol, fbs_over_120,
                             ekg_results, max_hr, exercise_angina, st_depression, slope_of_st,
                             number_of_vessels, thallium]])
    prediction = model.predict(input_array)

    return render_template('result.html', name=name, prediction=prediction[0])

if __name__ == "__main__":
    app.run(port=5000, debug=True)
